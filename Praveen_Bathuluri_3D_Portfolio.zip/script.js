// Responsive navigation
const toggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.textContent = open ? '×' : '☰';
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = '☰';
  }));
}

// Respect accessibility settings and avoid heavy effects on touch-first devices.
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const finePointer = window.matchMedia('(pointer: fine)').matches;

// Reveal sections as they enter the viewport.
if (!reduceMotion && 'IntersectionObserver' in window) {
  const sections = document.querySelectorAll('main > .section:not(.hero)');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  sections.forEach(section => {
    section.classList.add('reveal-ready');
    observer.observe(section);
  });
}

// Lightweight 3D tilt on the hero code panel and portfolio cards.
if (!reduceMotion && finePointer) {
  const tiltTargets = [
    ...document.querySelectorAll('.hero-card'),
    ...document.querySelectorAll('.skill-card'),
    ...document.querySelectorAll('.project-card'),
    ...document.querySelectorAll('.timeline')
  ];
  tiltTargets.forEach(el => {
    el.addEventListener('pointermove', event => {
      const rect = el.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width;
      const y = (event.clientY - rect.top) / rect.height;
      const rotateY = (x - 0.5) * 8;
      const rotateX = (0.5 - y) * 7;
      const isHero = el.classList.contains('hero-card');
      el.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) ${isHero ? 'translateZ(10px)' : 'translateY(-2px)'}`;
    });
    el.addEventListener('pointerleave', () => {
      el.style.transform = '';
    });
  });
}

// Subtle animated particle field with connecting lines; uses canvas only, no libraries.
const canvas = document.getElementById('particleCanvas');
if (canvas && !reduceMotion) {
  const ctx = canvas.getContext('2d');
  let width = 0, height = 0, particles = [], raf = 0;
  const pointer = { x: -1000, y: -1000 };
  const resize = () => {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.min(58, Math.max(24, Math.floor(width / 24)));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * width, y: Math.random() * height,
      vx: (Math.random() - .5) * .32, vy: (Math.random() - .5) * .32,
      r: Math.random() * 1.5 + .5
    }));
  };
  const draw = () => {
    ctx.clearRect(0, 0, width, height);
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      p.x += p.vx; p.y += p.vy;
      if (p.x < -10 || p.x > width + 10) p.vx *= -1;
      if (p.y < -10 || p.y > height + 10) p.vy *= -1;
      const dxp = p.x - pointer.x, dyp = p.y - pointer.y;
      const distancePointer = Math.hypot(dxp, dyp);
      if (distancePointer < 130) { p.x += dxp / Math.max(distancePointer, 1) * .18; p.y += dyp / Math.max(distancePointer, 1) * .18; }
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(137, 219, 231, 0.62)';
      ctx.fill();
      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j];
        const dx = p.x - q.x, dy = p.y - q.y;
        const d = Math.hypot(dx, dy);
        if (d < 105) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(139, 124, 255, ${0.14 * (1 - d / 105)})`;
          ctx.lineWidth = .7;
          ctx.stroke();
        }
      }
    }
    raf = requestAnimationFrame(draw);
  };
  window.addEventListener('resize', resize, { passive: true });
  window.addEventListener('pointermove', event => {
    pointer.x = event.clientX; pointer.y = event.clientY;
  }, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) cancelAnimationFrame(raf);
    else if (!reduceMotion) draw();
  });
  resize();
  draw();
}
