# Praveen Bathuluri — Interactive 3D Portfolio

A responsive, dark glassmorphism portfolio built with plain HTML, CSS, and JavaScript. No build tools or external JavaScript libraries are required.

## Run locally
1. Extract this ZIP file.
2. Open `index.html` in a modern browser.

Google Fonts are loaded online; the site otherwise runs as a static website.

## Interactive features
- Animated particle network background that reacts subtly to pointer movement
- 3D holographic orb with orbiting rings in the hero section
- Mouse-responsive 3D tilt on the code panel, skill cards, project cards, and experience panel
- Scroll reveal transitions
- Animated project visuals and floating technology tags
- Responsive mobile navigation
- Respects the device's reduced-motion accessibility preference

## Publish online
Upload the extracted folder to GitHub and import the repository into Vercel, or deploy the folder directly to a static host such as Netlify or GitHub Pages. This is a static HTML site; no build command is required and the publish directory is the project root.

## Before publishing
- Verify all profile details and contact links.
- Add GitHub/live-demo links for projects when available.
- Confirm that the included résumé PDF is the version you want to publish.
